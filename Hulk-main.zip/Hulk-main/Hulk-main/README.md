<p align="center">
	<img src="hulk.png" width="600px">
</p>


#### Version 1.0.0
#### By [TH3W1LDN16HT](https://github.com/W1LDN16H7)

# What is Hulk ?
**Hulk** is a tool that changes your ip and mac address to  a random Ip &amp; Mac address.It also support a mode that can coutinuously change the mac after a time.It is highly recommended to change the tool according to your need.

## Tested On :
<ul>
  <li>Kali Linux</li>
  
</ul>

# Installation:
```
git clone https://github.com/W1LDN16H7/Hulk.git
cd Hulk
chmod +x install.sh
./install.sh
```

# Suggestion
<p>Please use it wisely and if you know that how to fix network related problems on</p>
<p>Your testing system</p>
<p>Please Contribute in it</p>


# What to do when stuck
**Run  the following command in your terminal**

#### <code>systemctl stop NetworkManager</code>
**This will stop the network manager don't worry**
#### <code>systemctl restart NetworkManager</code>
**This will restart the network-manager now you're good to go**


# TODOs
<p>Make it advance with new concepts and add more features</p>
<p>Make the logic good</p>
<p>Include other tool and library in it </p>
<p>Clean the code if you can</p>

#### Licence
**This is under GNU General Public License v3.0**

