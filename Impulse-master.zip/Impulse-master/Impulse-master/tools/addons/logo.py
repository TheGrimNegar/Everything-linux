# Import modules
from colorama import Fore

# Logo
print(rf"""{Fore.MAGENTA}
  _____                       _          
  \_   \_ __ ___  _ __  _   _| |___  ___ 
   / /\/ '_ ` _ \| '_ \| | | | / __|/ _ \
/\/ /_ | | | | | | |_) | |_| | \__ \  __/
\____/ |_| |_| |_| .__/ \__,_|_|___/\___|
                 |_|    Created by LimerBoy
{Fore.RESET}""")
